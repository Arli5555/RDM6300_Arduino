# RDM6300_Arduino
You can observe the RDM6300 module working with this code
